package main;

import java.time.format.TextStyle;

import util.InsertSorter;
import util.MergeSorter;
import util.QuickSorter;
import util.SelectSorter;

public class Main {

    public static int ARR_SIZE = 10;
    public static int MAX_INT_VALUE = 100; //given value - 1

    public static void main(String[] args) {
        test1();
    }

    private static void printArray(int[] arr) {
        for (int i = 0; i < arr.length; i++) {
            System.out.print(arr[i] + " ");
        }
        System.out.println();
    }

    private static void test1(){
        DataSetGenerator dsg = new DataSetGenerator();

        int[] arr = dsg.generateRandomArray();

        int[] arr1 = arr.clone();
        int[] arr2 = arr.clone();
        int[] arr3 = arr.clone();
        int[] arr4 = arr.clone();

        InsertSorter.sort(arr1);
        MergeSorter.sort(arr2);
        QuickSorter.sort(arr3);
        SelectSorter.sort(arr4);

        printArray(arr);
        printArray(arr1);
        printArray(arr2);
        printArray(arr3);
        printArray(arr4);
    }

    public static int getARR_SIZE() {
        return ARR_SIZE;
    }
    public static void setARR_SIZE(int aRR_SIZE) {
        ARR_SIZE = aRR_SIZE;
    }
    public static int getMAX_INT_VALUE(){
        return MAX_INT_VALUE;
    }
    public static void setMAX_INT_VALUE(int mAX_INT_VALUE){
        MAX_INT_VALUE = mAX_INT_VALUE;
    }
}


/*
 * Data to display:
 * liczba porównań
 * liczba przepisań / zamian (1 zamiana = 3 przepisania)
 * zestawić wyniki w tabelce
 * nie stosować komparatorów
 * wyniki silustruj za pomocą odpowiednik wykresów
 */