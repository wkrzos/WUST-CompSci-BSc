package storagescheduler.schedulers;

import storagescheduler.DiskJob;
import storagescheduler.SchedulerReport;

import java.util.ArrayList;

public class SSTF implements Scheduler {
    ArrayList<DiskJob> queue = new ArrayList<>();
    @Override
    public void add(DiskJob job) {
        queue.add(job);
    }

    @Override
    public SchedulerReport execute() {
        int cylinderPos = 0;
        int cylinderShifts = 0;
        int idleTime = 0;

        while(queue.size() >0) {
            int idx = 0;
            int distance = Integer.MAX_VALUE;
            for(int i = 0 ; i < queue.size(); i++) {
                DiskJob job = queue.get(i);
                if(job.getArrivalTime() > cylinderShifts + idleTime) {
                    break;
                }
                int d = Math.abs(job.getCylinder() - cylinderPos);
                if(d < distance) {
                    distance = d;
                    idx = i;
                }
            }
            if(distance == Integer.MAX_VALUE) {
                idleTime++;
                continue;
            }
            DiskJob job = queue.remove(idx);
            cylinderShifts += Math.abs(cylinderPos - job.getCylinder());
            cylinderPos = job.getCylinder();

        }

        return new SchedulerReport(cylinderShifts, 0, idleTime);
    }
}
