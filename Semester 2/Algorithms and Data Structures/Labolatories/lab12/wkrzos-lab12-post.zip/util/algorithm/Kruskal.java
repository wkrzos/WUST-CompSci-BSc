package util.algorithm;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import util.DisjointSet;
import util.Edge;

public class Kruskal {

    public List<Edge> findMinimumSpanningTree(List<Edge> edges, int numVertices) {
        List<Edge> minimumSpanningTree = new ArrayList<>();
        DisjointSet disjointSet = new DisjointSet(numVertices);

        // Sort the edges in non-decreasing order of their weights
        Collections.sort(edges, (a, b) -> a.weight - b.weight);

        for (Edge edge : edges) {
            int root1 = disjointSet.find(edge.from);
            int root2 = disjointSet.find(edge.to);

            // Check if including this edge creates a cycle
            if (root1 != root2) {
                minimumSpanningTree.add(edge);
                disjointSet.union(root1, root2);
            }
        }

        return minimumSpanningTree;
    }
}