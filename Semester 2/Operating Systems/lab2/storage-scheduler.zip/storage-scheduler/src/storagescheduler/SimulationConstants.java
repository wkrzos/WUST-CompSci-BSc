package storagescheduler;

public class SimulationConstants {
    public static final int jobCount = 500;
    public static final int arrivalTimeSpread = 50;

    public static final int cylinderCount = 1024;
    public static final int sectorsPerCylinder = 1024;

    public static final int deadlineSpread = cylinderCount * 2;

    public static final int minimumDeadline = cylinderCount * 2;

    public static final int realTimeJobDistribution = 3;

}

