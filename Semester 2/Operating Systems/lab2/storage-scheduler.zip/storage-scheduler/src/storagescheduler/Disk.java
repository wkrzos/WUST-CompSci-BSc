package storagescheduler;

public class Disk {
    private int cylinders;
    private int sectorsPerCylinder;


    public Disk(int cylinders, int sectorsPerCylinder) {
        this.cylinders = cylinders;
        this.sectorsPerCylinder = sectorsPerCylinder;
    }

    public int getCylinders() {
        return cylinders;
    }

    public void setCylinders(int cylinders) {
        this.cylinders = cylinders;
    }

    public int getSectorsPerCylinder() {
        return sectorsPerCylinder;
    }

    public void setSectorsPerCylinder(int sectorsPerCylinder) {
        this.sectorsPerCylinder = sectorsPerCylinder;
    }

    public int getTotalDiskSize() {
        return cylinders * sectorsPerCylinder;
    }
}
