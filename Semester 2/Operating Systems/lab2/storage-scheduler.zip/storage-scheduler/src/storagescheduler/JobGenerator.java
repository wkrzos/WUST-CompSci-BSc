package storagescheduler;

import java.util.Random;

public class JobGenerator {
    private int lastArrivalTime = 0;
    private Disk disk;
    private Random random = new Random();

    public JobGenerator(Disk disk) {
        this.disk = disk;
    }

    public DiskJob generateJob() {
        int cylinder = random.nextInt(disk.getCylinders());
        int sector = random.nextInt(disk.getSectorsPerCylinder());
        int arrivalTime = random.nextInt() % 10 == 0 ? lastArrivalTime : (random.nextInt(SimulationConstants.arrivalTimeSpread) + lastArrivalTime);
        lastArrivalTime = arrivalTime;
        int deadline =
                random.nextInt() % SimulationConstants.realTimeJobDistribution == 0
                        ? Math.max(random.nextInt(SimulationConstants.deadlineSpread), SimulationConstants.minimumDeadline)
                        : 0;


        return new DiskJob(cylinder, sector, arrivalTime, deadline);

    }


}
