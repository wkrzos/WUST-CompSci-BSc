package storagescheduler.schedulers;

import storagescheduler.DiskJob;
import storagescheduler.SchedulerReport;

public interface Scheduler {

    void add(DiskJob job);
    SchedulerReport execute();
}
