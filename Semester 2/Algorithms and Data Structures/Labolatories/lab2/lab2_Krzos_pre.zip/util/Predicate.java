package util;

public interface Predicate<T> {
	boolean accept(T var);
}