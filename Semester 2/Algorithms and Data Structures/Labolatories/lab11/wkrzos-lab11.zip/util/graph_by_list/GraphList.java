package util.graph_by_list;

public interface GraphList {
    public void addEdge(int source, int destination);
    public void printGraph();
}
