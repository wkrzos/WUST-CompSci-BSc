package storagescheduler;


public enum ScanDirection {
    FORWARD,
    BACKWARD;

    public ScanDirection reverse() {
        return this == BACKWARD ? FORWARD : BACKWARD;
    }
}