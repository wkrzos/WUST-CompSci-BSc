import java.util.Arrays;

import util.PriorityHeap;
import util.RandomArrayGenerator;

public class Main {

    public static void main(String[] args) {
        System.out.println("Excercise 1:");
        Excercise1Test.testEx1();
        System.out.println("\nExcercise 2:");
        Excercise2Test.testEx2();
        System.out.println("\nExcercise 3:");
        Excercise3Test.testEx3();
    }
}