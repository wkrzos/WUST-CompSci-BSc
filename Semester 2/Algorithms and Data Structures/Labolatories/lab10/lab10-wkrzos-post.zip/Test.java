public class Test {
    public static void main(String[] args) {
        // Testing ForestComp
        System.out.println("Testing ForestComp:");
        ForestCompression forestComp = new ForestCompression();
        forestComp.makeSet(1);
        forestComp.makeSet(2);
        forestComp.makeSet(3);
        forestComp.union(1, 2);
        forestComp.union(2, 3);
        forestComp.print();

        // Testing ForestRank
        System.out.println("\nTesting ForestRank:");
        ForestRanking forestRank = new ForestRanking();
        forestRank.makeSet(1);
        forestRank.makeSet(2);
        forestRank.makeSet(3);
        forestRank.union(1, 2);
        forestRank.union(2, 3);
        forestRank.print();

        // Testing Tab
        System.out.println("\nTesting Tab:");
        Array tab = new Array(4);
        tab.makeSet(1);
        tab.makeSet(2);
        tab.makeSet(3);
        tab.union(1, 2);
        tab.union(2, 3);
        tab.print();

        // Testing TabComp
        System.out.println("\nTesting TabComp:");
        ArrayComparison tabComp = new ArrayComparison(4);
        tabComp.makeSet(1);
        tabComp.makeSet(2);
        tabComp.makeSet(3);
        tabComp.union(1, 2);
        tabComp.union(2, 3);
        tabComp.print();
    }
}
