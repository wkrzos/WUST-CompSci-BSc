package main;

import java.util.Random;

public class DataSetGenerator {

    public int[] generateRandomArray(){
        int[] arr = new int[Main.getARR_SIZE()];

        Random random = new Random();

        for(int i = 0; i < arr.length; i++){
            arr[i] = random.nextInt(Main.getMAX_INT_VALUE());
        }

        return arr;
    }
}

/* Testowanie wykonać na zbiorach danych: - losowym, - uporządkowanym odwrotnie do porządku sortowania, - uporządkowanym zgodnie z porządkiem sortowania,
a także dla różnych wielkości zbiorów, np:
- 8, 32, 128, 512, 2048 elementów. */

