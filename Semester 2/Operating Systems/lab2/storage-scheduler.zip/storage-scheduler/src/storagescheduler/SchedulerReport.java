package storagescheduler;

public class SchedulerReport {
    private int headShifts;
    private int rejectedJobs;

    private int idleTime;

    public SchedulerReport(int headShifts, int rejectedJobs, int idleTime) {
        this.headShifts = headShifts;
        this.rejectedJobs = rejectedJobs;
        this.idleTime = idleTime;
    }

    public int getHeadShifts() {
        return headShifts;
    }

    public int getRejectedJobs() {
        return rejectedJobs;
    }

    public int getIdleTime() {
        return idleTime;
    }
}
