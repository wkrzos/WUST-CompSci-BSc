package storagescheduler.schedulers;

import storagescheduler.DiskJob;
import storagescheduler.SchedulerReport;

import java.util.ArrayList;
import java.util.HashMap;

public class FCFS implements Scheduler{
    ArrayList<DiskJob> queue = new ArrayList<>();


    @Override
    public void add(DiskJob job) {
        queue.add(job);
    }

    @Override
    public SchedulerReport execute() {
        int cylinderPos = 0;
        int cylinderShifts = 0;
        int idleTime = 0;
        for(int i = 0 ; i < queue.size(); i++) {
            DiskJob job = queue.get(i);
            idleTime += Math.max(job.getArrivalTime() - cylinderShifts - idleTime, 0);
            cylinderShifts += Math.abs(job.getCylinder() - cylinderPos);
            cylinderPos = job.getCylinder();
        }


        return new SchedulerReport(cylinderShifts, 0, idleTime);
    }
}
