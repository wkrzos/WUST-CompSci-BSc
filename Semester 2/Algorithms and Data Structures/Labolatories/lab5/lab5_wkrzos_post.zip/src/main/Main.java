package main;

import java.util.Arrays;
import java.util.Comparator;

import utilOriginal.CarSorters;
import utilOriginal.SimpleComparator;
import utilLecture.CompoundComparator;
import utilLecture.NaturalComparator;

public class Main {

    // Potrzebna będzie metoda porównywująca wszystkie trzy pola!

    int CAR_ARR_SIZE = 5;

    static Car[] cars = new Car[5];

    public static void main(String[] args) {
        demo1_MyApproach();
        demo2_MyApproach();
    }

    public static void printCars(Car[] cars) {
        for (Car car : cars) {
            System.out.println("\n" + car.toString());
        }
    }

    private static void demo1_MyApproach() {

        System.out.println("===demo1===");

        // No sorting
        Car[] cars = {
                new Car("Ford", "Blue", 2011),
                new Car("Toyota", "Black", 2015),
                new Car("Honda", "Red", 2008),
                new Car("Ford", "Blue", 2012),
                // new Car("Kia", "Orange", 2014)
        };

        System.out.println("\nUnsorted: ");
        printCars(cars);

        // Bubble sort by brand
        CarSorters.bubbleSort(cars, Comparator.comparing(s -> s.brand));
        System.out.println("\nSorted by brand (bubble sort): ");
        printCars(cars);

        // Insertion sort by year of production
        CarSorters.insertionSort(cars, Comparator.comparingInt(s -> s.yearOfProduction));
        System.out.println("\nSorted by year of production (insertion sort): ");
        printCars(cars);

        // Selection sort by colour
        CarSorters.selectionSort(cars, Comparator.comparing(s -> s.colour));
        System.out.println("\nSorted by colour (selection sort): ");
        printCars(cars);

        // Insertion sort with complex comparator (EXTRA)
        Arrays.sort(cars, (s1, s2) -> {
            if (s1.brand.compareTo(s2.brand) != 0) {
                return s1.brand.compareTo(s2.brand);
            } else if (s1.colour
                    .compareTo(s2.colour) != 0) {
                return s1.colour
                        .compareTo(s2.colour);
            } else {
                return Integer.compare(s1.yearOfProduction, s2.yearOfProduction);
            }
        });

        System.out.println("\nPosortowane z wykorzystaniem złożonej metody porównywania (insertion sort): ");
        printCars(cars);

    }

    private static void demo2_MyApproach() {

        System.out.println("===demo2===");

        Car[] cars = {
                new Car("Ford", "Blue", 2011),
                new Car("Toyota", "Black", 2015),
                new Car("Honda", "Red", 2008),
                new Car("Ford", "Agave", 2011),
                // new Car("Kia", "Orange", 2014)
        };

        Comparator<Car> naturalComparator = new NaturalComparator<Car>();

        SimpleComparator simpleBrandComparator = new SimpleComparator("brand");
        SimpleComparator simpleColourComparator = new SimpleComparator("colour");
        SimpleComparator simpleYearOfProductionComparator = new SimpleComparator("yearOfProduction");

        CompoundComparator<Car> compundComparatorYCB = new CompoundComparator<>();
        compundComparatorYCB.addComparator(simpleYearOfProductionComparator);
        compundComparatorYCB.addComparator(simpleColourComparator);
        compundComparatorYCB.addComparator(simpleBrandComparator);

        CarSorters.bubbleSort(cars, naturalComparator);
        System.out.println("\n>bubble sort: ");
        printCars(cars);

        CarSorters.insertionSort(cars, simpleBrandComparator);
        System.out.println("\n>insertion sort: ");
        printCars(cars);

        CarSorters.selectionSort(cars, compundComparatorYCB);
        System.out.println("\n>selection sort: ");
        printCars(cars);
    }
}
