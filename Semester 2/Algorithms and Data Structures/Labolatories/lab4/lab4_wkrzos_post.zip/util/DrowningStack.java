package util;

import java.util.NoSuchElementException;

public class DrowningStack<E> {
    private E[] array;
    private int size;
    private int top;
    private int bottom;

    public DrowningStack(int capacity) {
        this.array = (E[]) new Object[capacity];
        this.size = 0;
        this.top = 0;
        this.bottom = 0;
    }

    public void push(E item) {
        if (size == array.length) {
            bottom = (bottom + 1) % array.length;
        } else {
            size++;
        }
        array[top] = item;
        top = (top + 1) % array.length;
    }

    public E pop() {
        if (isEmpty()) {
            throw new NoSuchElementException("Stack is empty");
        }
        E item = array[(top - 1 + array.length) % array.length];
        top = (top - 1 + array.length) % array.length;
        size--;
        return item;
    }

    public E peek() {
        if (isEmpty()) {
            throw new NoSuchElementException("Stack is empty");
        }
        return array[(top - 1 + array.length) % array.length];
    }

    public boolean isEmpty() {
        return size == 0;
    }

    public int size() {
        return size;
    }
}