package main;

import util.CSCAN;
import util.EDF;
import util.FCFS;
import util.FDSCAN;
import util.RandomProcessGenerator;
import util.SCAN;
import util.SSTF;
import util.schedulingAlgorithms.*;

public class Main {
    public static void main(String[] args) {

        int head = 50;
        int direction = 1;

        int[] requests = {98, 183, 37, 122, 14, 124, 65, 67}; // przykładowa kolejka żądań
        int[] deadlines = {200, 300, 250, 500, 150, 400, 300, 350 };

        //Randomized
        //int maxTrack = 100; // maksymalna liczba bloków na dysku
        //int[] requests = RandomProcessGenerator.generate(maxTrack, 150);
        //int[] deadlines = RandomProcessGenerator.generateRandomDeadlines(requests, 100);

        
        // testowanie algorytmu FCFS
        int fcfsSeekCount = FCFS.sortFCFS(requests, head);
        System.out.println("FCFS: " + fcfsSeekCount);
        
        // testowanie algorytmu SSTF
        int sstfSeekCount = SSTF.sortSSTF(requests, head);
        System.out.println("SSTF: " + sstfSeekCount);
        
        // testowanie algorytmu SCAN
        int scanSeekCount = SCAN.sortSCAN(requests, head, direction);
        System.out.println("SCAN: " + scanSeekCount);
        
        // testowanie algorytmu C-SCAN
        int cScanSeekCount = CSCAN.sortCSCAN(requests, head, direction);
        System.out.println("C-SCAN: " + cScanSeekCount);
        
        // testowanie algorytmu EDF
        int edfSeekCount = EDF.sortEDF(requests, head, deadlines);
        System.out.println("EDF: " + edfSeekCount);
        
        // testowanie algorytmu FD-SCAN
        int fdScanSeekCount = FDSCAN.sortFDSCAN(requests, head, deadlines, direction);
        System.out.println("FD-SCAN: " + fdScanSeekCount);
    }
}