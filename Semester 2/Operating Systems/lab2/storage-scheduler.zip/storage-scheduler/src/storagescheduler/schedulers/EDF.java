package storagescheduler.schedulers;

import storagescheduler.DiskJob;
import storagescheduler.SchedulerReport;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;

public class EDF implements Scheduler {

    private ArrayList<DiskJob>priorityQueue = new ArrayList<>();
    private ArrayList<DiskJob>queue = new ArrayList<>();
    private int rejectedJobs = 0;

    @Override
    public void add(DiskJob job) {
        if(job.getDeadline() != 0) {

            priorityQueue.add(job);
        } else {
            queue.add(job);
        }
    }

    private int findNextPriorityJob(int time, int pos) {
        int idx = -1;
        int remainingTime = Integer.MAX_VALUE;
        for(int i = 0 ; i < this.priorityQueue.size(); i++) {
            DiskJob job = priorityQueue.get(i);
            if(job.getArrivalTime() > time) {
                continue;
            }
            int r = job.getDeadline() - (time - job.getArrivalTime());
            if(Math.abs(pos - job.getCylinder()) > r) {
                rejectedJobs++;
                priorityQueue.remove(i);
                i--;
                continue;
            }
            if(r < remainingTime) {
                remainingTime =r;
                idx = i;
            }

        }

        return idx;
    }
    private int findNextJob(int time, int pos) {
        int idx = -1;
        int distance = Integer.MAX_VALUE;

        for(int i = 0 ; i < this.queue.size(); i++) {
            DiskJob job = queue.get(i);
            if(job.getArrivalTime() > time) {
                continue;
            }
            int d = Math.abs(pos - job.getCylinder());

            if(d < distance) {
                distance = d;
                idx = i;
            }

        }
        return idx;
    }

    @Override
    public SchedulerReport execute() {
        priorityQueue.sort(Comparator.comparingInt(DiskJob::getMaxHandleTime));
        queue.sort(Comparator.comparingInt(DiskJob::getCylinder));
        int cylinderPos = 0;
        int cylinderShifts = 0;
        int idleTime = 0;

        while(priorityQueue.size() > 0 || queue.size() > 0) {
            int totalTime = cylinderShifts + idleTime;
            int nextPriorityJob = findNextPriorityJob(totalTime, cylinderPos);
            if(nextPriorityJob != -1) {
                DiskJob job = priorityQueue.remove(nextPriorityJob);
                cylinderShifts += Math.abs(job.getCylinder() - cylinderPos);
                cylinderPos = job.getCylinder();
                continue;
            }
            int nextJob = findNextJob(totalTime, cylinderPos);
            if(nextJob == -1 ) {
                idleTime++;
                continue;
            }
            DiskJob job = queue.remove(nextJob);

            cylinderShifts += Math.abs(job.getCylinder() - cylinderPos);
            cylinderPos = job.getCylinder();


        }


        return new SchedulerReport(cylinderShifts, rejectedJobs, idleTime);
    }
}
