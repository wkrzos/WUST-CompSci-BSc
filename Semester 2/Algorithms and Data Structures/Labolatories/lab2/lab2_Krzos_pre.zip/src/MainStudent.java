//Użyj 3 sposobów używani predykatu: (chyba) interfejs, klasa anonimowa, lambda

package src;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Scanner;
import java.util.function.Predicate;

import util.ArrayIterator;
import util.FilterIterator;

class Main {
    private static Student[] studentList = new Student[0];
    private static Student[] studentsGradeBelowThree = new Student[studentList.length];
    private static Student[] studentsGradeAboveEqualThree = new Student[studentList.length];

    public static void main(String[] args) throws FileNotFoundException {
        readStudents("students1.txt");
        System.out.println("__________Test__________");
        printStudentList(studentList);

        changeAverageGrade(studentList, "123456", 2.5);
        printStudentList(studentList);

        studentListToGradedLists(studentList, studentsGradeBelowThree, studentsGradeAboveEqualThree);

        System.out.println("\n|Graded lists");
        System.out.println("\nGrades below three:");
        printStudentList(studentsGradeBelowThree);
        System.out.println("\nGrades equall or above three");
        printStudentList(studentsGradeAboveEqualThree);

        printStudentsAboveGrade(studentList, 4);
    }

    public static void readStudents(String fileName) throws FileNotFoundException {

        try {
            String[] readObject;
            File obj = new File(fileName);
            Scanner fileScanner = new Scanner(obj);
    
            fileScanner.nextLine();
            fileScanner.nextLine();
    
            while (fileScanner.hasNextLine()) {
                String data = fileScanner.nextLine();
                readObject = data.split(" ");
    
                String tempIndex = readObject[2].replace("(", "");
                String index = tempIndex.replace(")", "");
    
                double averageGrade = (Double.parseDouble(readObject[3]) + Double.parseDouble(readObject[4])) / 2;
    
                Student student = new Student(index, readObject[1], readObject[0], averageGrade);
    
                studentList = addToArray(studentList.length, studentList, student);
            }
    
            fileScanner.close();
            
        } catch (Exception fileNotFOuException) {
            System.out.println("bonk!");
        }
    }

    private static void printStudentList(Student[] inputList) {
        System.out.println("\nStudent list:");

        ArrayIterator<Student> iter = new ArrayIterator<>(inputList);

        while (iter.hasNext()) {
            iter.next().getState();
        }
    }

    public static void changeAverageGrade(Student[] inputList, String index, double grade){
        System.out.println("\n|Grade changed________");

        Iterator<Student> iter = new ArrayIterator<Student>(inputList);

        Predicate<Student> indexFilter = new Predicate<Student>() {
            public boolean accept(Student student){
                return student.getIndex().equals(index);
            }

            @Override
            public boolean test(Student t) {
                // TODO Auto-generated method stub
                throw new UnsupportedOperationException("Unimplemented method 'test'");
            }
        };
        FilterIterator<Student> filterIter = new FilterIterator<Student>(iter, indexFilter);

        while(filterIter.hasNext()){
            filterIter.next().setAverageGrade(grade);
        }
    }

    private static void studentListToGradedLists(Student inputList[], Student outputListBelowThree[],
            Student outputListAboveThree[]) {

        Iterator<Student> iter1 = new ArrayIterator<>(inputList);
        Iterator<Student> iter2 = new ArrayIterator<>(inputList);

        Predicate<Student> preAbove = new Predicate<Student>() {
            @Override
            public boolean accept(Student student) {
                return student.getAverageGrade() >= 3;
            }

            @Override
            public boolean test(Student t) {
                // TODO Auto-generated method stub
                throw new UnsupportedOperationException("Unimplemented method 'test'");
            }
        };

        Predicate<Student> preBelow = new Predicate<Student>() {
            @Override
            public boolean accept(Student student) {
                return student.getAverageGrade() < 3;
            }

            @Override
            public boolean test(Student t) {
                // TODO Auto-generated method stub
                throw new UnsupportedOperationException("Unimplemented method 'test'");
            }
        };

        FilterIterator<Student> filterIterAbove = new FilterIterator<>(iter1, preAbove);
        FilterIterator<Student> filterIterBelow = new FilterIterator<>(iter2, preBelow);

        while (filterIterAbove.hasNext()) {
            addToArray(outputListAboveThree.length, outputListAboveThree, filterIterAbove.next());
        }

        while (filterIterBelow.hasNext()) {
            addToArray(outputListBelowThree.length, outputListAboveThree, filterIterAbove.next());
        }

        studentsGradeBelowThree = outputListBelowThree;
        studentsGradeAboveEqualThree = outputListAboveThree;
    }

    private static void printStudentsAboveGrade(Student[] inputList, double gradeFilter) {
        System.out.println("\n|Students above " + gradeFilter + ": ");

        Student tempStudentList[] = new Student[studentList.length];

        Iterator<Student> iter = new ArrayIterator<>(inputList);
        Predicate<Student> grade = new Predicate<Student>() {
            @Override
            public boolean accept(Student student) {
                return student.getAverageGrade() > gradeFilter;
            }

            @Override
            public boolean test(Student t) {
                // TODO Auto-generated method stub
                throw new UnsupportedOperationException("Unimplemented method 'test'");
            }
        };
        FilterIterator<Student> filterIterator = new FilterIterator<>(iter, grade);

        while (filterIterator.hasNext()) {
            addToArray(studentList.length, tempStudentList, filterIterator.next());
        }

        printStudentList(tempStudentList);
    }

    public static Student[] addToArray(int n, Student inputArray[], Student studentToAdd)
    {
        int i;
    
        Student newarr[] = new Student[n + 1];
    
        for (i = 0; i < n; i++)
            newarr[i] = inputArray[i];
    
        newarr[n] = studentToAdd;
    
        return newarr;
    }
}