package CharacterListGenerator;

public class School {
    
    public static void getEducated(Player p){
        p.setIfIntelligent(true);
    }
}
