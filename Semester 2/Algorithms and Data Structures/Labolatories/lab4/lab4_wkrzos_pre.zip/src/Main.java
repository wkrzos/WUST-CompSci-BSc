package src;

import util.Queue;
import util.Stack;

public class Main {
    public static void main(String[] args){
        System.out.println("===demo1===");
        demo1();
        System.out.println("===demo2===");
        demo2();
    }

    private static void demo1(){
        Queue<Integer> queue = new Queue<>();

        queue.enqueue(1);
        queue.enqueue(2);
        queue.enqueue(3);

        System.out.println(queue.peek()); 

        System.out.println(queue.dequeue()); 

        System.out.println(queue.peek()); 
    }

    private static void demo2(){
        Stack<Integer> stack = new Stack<>();

        stack.push(1);
        stack.push(2);
        stack.push(3);

        System.out.println(stack.peek());
        
        System.out.println(stack.pop()); 

        System.out.println(stack.peek());
    }
}
