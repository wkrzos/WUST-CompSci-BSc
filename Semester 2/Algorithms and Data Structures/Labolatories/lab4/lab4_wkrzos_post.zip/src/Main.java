package src;

import util.DoublyLinkedList;
import util.Queue;
import util.Stack;

public class Main {
    public static void main(String[] args){
        System.out.println("===demo1===");
        demo1();
        System.out.println("===demo2===");
        demo2();
        System.out.println("===demo3===");
        demo3();
        System.out.println("===demo4===");
        demo4();
    }

    private static void demo1(){
        Queue<Integer> queue = new Queue<>();

        queue.enqueue(1);
        queue.enqueue(2);
        queue.enqueue(3);

        System.out.println(queue.peek()); 

        System.out.println(queue.dequeue()); 

        System.out.println(queue.peek()); 
    }

    private static void demo2(){
        Stack<Integer> stack = new Stack<>();

        stack.push(1);
        stack.push(2);
        stack.push(3);

        System.out.println(stack.peek());
        
        System.out.println(stack.pop()); 

        System.out.println(stack.peek());
    }

    private static void demo3(){
        DoublyLinkedList list1 = new DoublyLinkedList();
        DoublyLinkedList list2 = new DoublyLinkedList();
        DoublyLinkedList list3 = new DoublyLinkedList();
        DoublyLinkedList list4 = new DoublyLinkedList();

        list1.addLast(1);
        list1.addLast(2);

        list2.addLast(3);
        list2.addLast(4);
        
        list1.displayList();
        list2.displayList();

        list3 = list1.joinListsAtEnd(list2);
        list4 = list1.joinListsBeforeIndex(list2, 1);

        list3.displayList();
        list4.displayList();
    }

    private static void demo4(){
        PostfixEvaluator pe = new PostfixEvaluator();

        String postfixExpression = pe.readPostfixExpressionFromFile("equat.ion");
        System.out.println("Postfix Expression: " + postfixExpression);

        int result = pe.evaluatePostfixExpression(postfixExpression);
        System.out.println("Result: " + result);
    }
}
