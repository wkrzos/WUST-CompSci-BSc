package util.algorithm;

import java.util.ArrayList;
import java.util.List;
import java.util.PriorityQueue;

import util.Edge;

public class Prim {

    public static List<Edge> findMinimumSpanningTree(List<Edge>[] adjacencyList) {
        int numVertices = adjacencyList.length;
        boolean[] visited = new boolean[numVertices];
        int[] parent = new int[numVertices];
        int[] key = new int[numVertices];

        for (int i = 0; i < numVertices; i++) {
            key[i] = Integer.MAX_VALUE;
        }

        key[0] = 0;
        parent[0] = -1;

        PriorityQueue<Edge> minHeap = new PriorityQueue<>();
        minHeap.offer(new Edge(0, 0, 0));

        while (!minHeap.isEmpty()) {
            Edge currentEdge = minHeap.poll();
            int u = currentEdge.to;

            if (visited[u]) {
                continue;
            }

            visited[u] = true;

            for (Edge edge : adjacencyList[u]) {
                int v = edge.to;
                int weight = edge.weight;

                if (!visited[v] && weight < key[v]) {
                    parent[v] = u;
                    key[v] = weight;
                    minHeap.offer(new Edge(u, v, weight));
                }
            }
        }

        List<Edge> minimumSpanningTree = new ArrayList<>();
        for (int i = 1; i < numVertices; i++) {
            int from = parent[i];
            int to = i;
            int weight = key[i];
            minimumSpanningTree.add(new Edge(from, to, weight));
        }

        return minimumSpanningTree;
    }
}
