public class WSJF extends SJF{
    
}
