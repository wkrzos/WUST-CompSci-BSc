package util;

public class HashTable<K, V> {
    private int capacity;
    private int size;
    private HashEntry<K, V>[] table;

    public HashTable(int initialCapacity) {
        this.capacity = initialCapacity;
        this.size = 0;
        this.table = new HashEntry[capacity];
    }

    public V get(K key) {
        int index = hashFunction(key);
        int i = 0;
        while (table[index] != null && !table[index].getKey().equals(key) && i < capacity) {
            i++;
            index = probeSequence(key, i);
        }
        if (table[index] != null && table[index].getKey().equals(key)) {
            return table[index].getValue();
        } else {
            return null;
        }
    }

    public void put(K key, V value) {
        if ((size + 1) * 1.0 / capacity >= 0.75) {
            resize();
        }
        int index = hashFunction(key);
        int i = 0;
        while (table[index] != null && !table[index].getKey().equals(key) && i < capacity) {
            i++;
            index = probeSequence(key, i);
        }
        if (table[index] == null) {
            table[index] = new HashEntry<>(key, value);
            size++;
        } else {
            table[index].setValue(value);
        }
    }

    public boolean containsKey(K key) {
        int index = hashFunction(key);
        int i = 0;
        while (table[index] != null && !table[index].getKey().equals(key) && i < capacity) {
            i++;
            index = probeSequence(key, i);
        }
        return table[index] != null && table[index].getKey().equals(key);
    }

    public int size() {
        return size;
    }

    public boolean isEmpty() {
        return size == 0;
    }

    public void resize() {
        int newCapacity = capacity * 2;
        HashEntry<K, V>[] newTable = new HashEntry[newCapacity];
        for (int i = 0; i < capacity; i++) {
            if (table[i] != null) {
                int index = hashFunction(table[i].getKey());
                int j = 0;
                while (newTable[index] != null && j < newCapacity) {
                    j++;
                    index = probeSequence(table[i].getKey(), j);
                }
                newTable[index] = table[i];
            }
        }
        capacity = newCapacity;
        table = newTable;
    }

    public void dump() {
        for (int i = 0; i < capacity; i++) {
            if (table[i] == null) {
                System.out.println("[" + i + "]: null");
            } else {
                System.out.println("[" + i + "]: " + table[i].getKey() + " => " + table[i].getValue());
            }
        }
    }

    private int hashFunction(K key) {
        // funkcja haszująca dla klucza
        return Math.abs(key.hashCode() % capacity);
    }

    private int probeSequence(K key, int i) {
        // sekwencja próbkowania dla adresowania otwartego liniowego
        // return (hashFunction(key) + i) % capacity;

        // sekwencja próbkowania dla adresowania otwartego kwadratowego
        // return (hashFunction(key) + i * i) % private int probeSequence(K key, int i)
        // {
        // sekwencja próbkowania dla adresowania otwartego liniowego
        // return (hashFunction(key) + i) % capacity;

        // sekwencja próbkowania dla adresowania otwartego kwadratowego
        // return (hashFunction(key) + i * i) % capacity;

        // sekwencja próbkowania dla podwójnego haszowania
        int h1 = hashFunction(key);
        int h2 = 1 + Math.abs(key.hashCode() % (capacity - 1));
        return (h1 + i * h2) % capacity;
    }

    private static class HashEntry<K, V> {
        private K key;
        private V value;

        public HashEntry(K key, V value) {
            this.key = key;
            this.value = value;
        }

        public K getKey() {
            return key;
        }

        public V getValue() {
            return value;
        }

        public void setValue(V value) {
            this.value = value;
        }
    }
}
