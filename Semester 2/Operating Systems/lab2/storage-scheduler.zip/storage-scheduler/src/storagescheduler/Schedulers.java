package storagescheduler;

import storagescheduler.schedulers.*;

import java.util.ArrayList;

public class Schedulers {

    private Disk disk;
    private JobGenerator generator;
    private Scheduler[] schedulers;


    public Schedulers(int cylinders, int sectorsPerCylinder) {
        disk = new Disk(cylinders, sectorsPerCylinder);
        generator = new JobGenerator(disk);
        this.schedulers = new Scheduler[] { new FCFS(), new SSTF(), new SCAN(disk), new CSCAN(disk), new EDF(), new FDSCAN() };
        for(int i = 0 ; i < SimulationConstants.jobCount; i++) {
            DiskJob job = generator.generateJob();
            for(var scheduler : schedulers) {
                scheduler.add(job);
            }

        }

    }


    public void printSummary() {
        for(var scheduler : schedulers) {
            SchedulerReport report = scheduler.execute();
            System.out.println(String.format("%s: ruchy glowica: %d, czas bezczynosci: %d, odrzucone zadania: %d", scheduler.getClass().getSimpleName(), report.getHeadShifts(), report.getIdleTime(), report.getRejectedJobs()));
        }
    }


}
