import util.PriorityHeap;

public class HeapTest {
    public static void main(String[] args) {
        int[] arr = {5, 3, 8, 2, 7, 1, 4};
        PriorityHeap pq = new PriorityHeap(arr.length);
    
        // dodaj elementy do kolejki priorytetowej
        for (int i = 0; i < arr.length; i++) {
            pq.enqueue(arr[i]);
        }
    
        System.out.println("Kolejka priorytetowa:");
        pq.printHeap(); // oczekiwany wynik: 8 7 4 2 3 1 5
    
        // usuń element z indeksem 3 z kolejki priorytetowej
        pq.remove(3);
        System.out.println("Kolejka priorytetowa po usunięciu elementu z indeksem 3:");
        pq.printHeap(); // oczekiwany wynik: 8 7 4 5 3 1
    
        // zmień priorytet elementu o indeksie 2 w kolejce priorytetowej
        pq.changePriority(2, 9);
        System.out.println("Kolejka priorytetowa po zmianie priorytetu elementu o indeksie 2:");
        pq.printHeap(); // oczekiwany wynik: 9 8 4 5 3 1 7
    
        // posortuj elementy tablicy za pomocą kolejki priorytetowej
        for (int i = 0; i < arr.length; i++) {
            arr[i] = pq.dequeue();
        }
    
        System.out.println("Tablica posortowana:");
        for (int i = 0; i < arr.length; i++) {
            System.out.print(arr[i] + " ");
        }
        System.out.println(); // oczekiwany wynik: 1 3 4 5 7 8 9
    }   
}
