import util.PriorityHeap;
import util.RandomArrayGenerator;

public class Main{

    public static void  main(String[] args){
        RandomArrayGenerator rag = new RandomArrayGenerator(10, 10);
        PriorityHeap ph = rag.generateRandomArray();
        ph.printHeap();
    }

    
}