package src;

import util.PrimeIterator;

public class MainPrime {
    public static void main(String[] args){
        generatePrimeNumbers();
    }

    public static void generatePrimeNumbers(){
        PrimeIterator fpi = new PrimeIterator(0, 65);

        while(fpi.hasNext()){
            System.out.println(fpi.next());
        }
    }
}
