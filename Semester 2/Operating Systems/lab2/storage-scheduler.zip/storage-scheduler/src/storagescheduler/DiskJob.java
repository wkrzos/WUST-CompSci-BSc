package storagescheduler;

public class DiskJob {
    private int cylinder;
    private int sector;
    private int arrivalTime;
    private int deadline; // time since arrivalTime or 0 if no deadline


    public DiskJob(int cylinder, int sector, int arrivalTime, int deadline) {
        this.cylinder = cylinder;
        this.sector = sector;
        this.arrivalTime = arrivalTime;
        this.deadline = deadline;
    }

    public int getCylinder() {
        return cylinder;
    }

    public void setCylinder(int cylinder) {
        this.cylinder = cylinder;
    }

    public int getSector() {
        return sector;
    }

    public void setSector(int sector) {
        this.sector = sector;
    }

    public int getArrivalTime() {
        return arrivalTime;
    }

    public void setArrivalTime(int arrivalTime) {
        this.arrivalTime = arrivalTime;
    }

    public int getDeadline() {
        return deadline;
    }

    public void setDeadline(int deadline) {
        this.deadline = deadline;
    }

    public int getMaxHandleTime() {
        return arrivalTime + deadline;
    }
}
