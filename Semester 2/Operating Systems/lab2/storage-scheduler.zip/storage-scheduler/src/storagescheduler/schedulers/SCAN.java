package storagescheduler.schedulers;

import storagescheduler.Disk;
import storagescheduler.DiskJob;
import storagescheduler.ScanDirection;
import storagescheduler.SchedulerReport;

import java.util.ArrayList;
import java.util.Comparator;

public class SCAN implements Scheduler {
    private ArrayList<DiskJob> queue = new ArrayList<>();

    private Disk disk;

    public SCAN(Disk disk) {
        this.disk = disk;
    }

    @Override
    public void add(DiskJob job) {

        queue.add(job);
    }

    private int findNextJob(ScanDirection scanDirection, int time, int pos) {
        if(scanDirection == ScanDirection.FORWARD) {
            for(int i = 0 ; i < queue.size(); i ++) {
                int distance = Math.abs(pos - queue.get(i).getCylinder());
                if(queue.get(i).getCylinder() >= pos && queue.get(i).getArrivalTime() <= time + distance) {
                    return i;
                }
            }
        }
        else {
            for(int i = queue.size() - 1; i >= 0 ; i--) {
                int distance = Math.abs(pos - queue.get(i).getCylinder());

                if(queue.get(i).getCylinder() <= pos && queue.get(i).getArrivalTime() <= time + distance) {
                    return i;
                }
            }
        }
        return -1;
    }


    @Override
    public SchedulerReport execute() {
        queue.sort(Comparator.comparing(DiskJob::getCylinder).thenComparing(DiskJob::getArrivalTime));
        int cylinderPos = 0;
        int cylinderShifts = 0;
        int idleTime = 0;
        ScanDirection direction = ScanDirection.FORWARD;
        while (queue.size() > 0) {

            int totalTime = cylinderShifts + idleTime;
            int nextPos = findNextJob(direction, totalTime, cylinderPos);
            if (nextPos == -1) {
                int newPos = direction == ScanDirection.FORWARD ? disk.getCylinders() - 1 : 0;
                cylinderShifts+= Math.abs(cylinderPos - newPos);
                cylinderPos = direction == ScanDirection.FORWARD ? disk.getCylinders() - 1 : 0;
                direction = direction.reverse();
                continue;
            }
            DiskJob diskJob = queue.remove(nextPos);
            cylinderShifts += Math.abs(diskJob.getCylinder() - cylinderPos);
            cylinderPos = diskJob.getCylinder();

        }
        return new SchedulerReport(cylinderShifts, 0, idleTime);

    }
}
