package src;

public class ListMerger{

    public class Node {
        private int value;
        private Node prev;
        private Node next;
    
        public Node(int value) {
            this.value = value;
            this.prev = null;
            this.next = null;
        }
    
        public int getValue() {
            return this.value;
        }
    
        public Node getPrev() {
            return this.prev;
        }
    
        public void setPrev(Node node) {
            this.prev = node;
        }
    
        public Node getNext() {
            return this.next;
        }
    
        public void setNext(Node node) {
            this.next = node;
        }
    }

    public Node mergeListsEnd(Node lista1, Node lista2) {
        if (lista1 == null) {
            return lista2;
        }
        if (lista2 == null) {
            return lista1;
        }
    
        Node tail = lista1;
        while (tail.getNext() != null) {
            tail = tail.getNext();
        }
        tail.setNext(lista2);
        lista2.setPrev(tail);
    
        return lista1;
    }

    public Node mergeListsBefore(Node lista1, Node lista2, int index) {
        if (lista1 == null) {
            return lista2;
        }
        if (lista2 == null) {
            return lista1;
        }
    
        if (index == 0) {
            lista2.setPrev(null);
            lista1.setPrev(lista2);
            lista2.setNext(lista1);
            return lista2;
        }
    
        Node current = lista1;
        for (int i = 0; i < index-1; i++) {
            if (current.getNext() == null) {
                break;
            }
            current = current.getNext();
        }
    
        Node temp = current.getNext();
        current.setNext(lista2);
        lista2.setPrev(current);
        lista2.setNext(temp);
        if (temp != null) {
            temp.setPrev(lista2);
        }
    
        return lista1;
    }
}