import storagescheduler.Schedulers;
import storagescheduler.SimulationConstants;

public class Main {
    public static void main(String[] args) {
        Schedulers schedulers = new Schedulers(SimulationConstants.cylinderCount, SimulationConstants.sectorsPerCylinder);
        schedulers.printSummary();
    }
}